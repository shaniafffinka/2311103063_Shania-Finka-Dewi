
<?php echo "Nama: " . $_GET['nama']; ?>